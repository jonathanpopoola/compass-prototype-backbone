define([
	'jquery',
	'underscore',
	'backbone',
	'text!templates/newshome.html',
	
],function($, _, Backbone, newshome) {
	var newshomeView = Backbone.View.extend({
		el : $('#mainContainer'),
		
		initialize : function() {			
		},
		
		render : function() {
			this.$el.html(newshome);
		}

	});
	return new newshomeView;
});
