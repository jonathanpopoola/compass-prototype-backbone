define([
	'jquery',
	'underscore',
	'backbone',
	'text!templates/home.html',
	
],function($, _, Backbone, home) {
	var homeView = Backbone.View.extend({
		el : $('#mainContainer'),
		
		initialize : function() {
			console.log("home init");
			
		},
		

		render : function() {
			this.$el.html(home);
			this.triggerCarousel();
		},
		
		triggerCarousel: function() {
			$('.carousel').carousel({
    			interval:3000 //2000 milliseconds = 2s
			});
		}
		
	});
	return new homeView;
});
