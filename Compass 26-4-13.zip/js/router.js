define([
  'jquery',
  'underscore',
  'backbone',
  'views/common/header',
  'views/common/footer',
  'views/home',
  'views/faq',
  'views/newshome',


  
], function($, _, Backbone, headerView, footerView, homeView, faqView, newshomeView){
	
	function getActions(actions) {
		return actions;
	}
	
	var AppRouter = Backbone.Router.extend({
		currentView: null,
		
		initialize: function() {
			this.showView(headerView);
			this.showView(footerView);
		},
	
		routes: {
			'': 'defaultAction',
			'faqView' : 'showFaq',
			'newshome' : 'newshomeShow',
		
		},

		defaultAction: function(actions){
			this.showView(homeView);
		},
		
		showView: function(view) {
			view.render();
			if(view.postRender){
				view.postRender();
			}
		},
		
		showFaq: function(actions) {
			this.showView(faqView);
		},
		
		newshomeShow: function(actions) {
			this.showView(newshomeView); 
		}
		
	});

	var initialize = function(){
		new AppRouter();
		Backbone.history.start();
	};

	return {
		initialize: initialize
	};
});
