define([
  'jquery',
  'underscore',
  'backbone',
  'views/common/header',
  'views/common/footer',
  'views/home',


  
], function($, _, Backbone, headerView, footerView, homeView){
	
	function getActions(actions) {
		return actions;
	}
	
	var AppRouter = Backbone.Router.extend({
		currentView: null,
		
		initialize: function() {
			this.showView(headerView);
			this.showView(footerView);
		},
	
		routes: {
			'': 'defaultAction',
		
		},

		defaultAction: function(actions){
			this.showView(homeView);
		},
		
		showView: function(view) {
			view.render();
			if(view.postRender){
				view.postRender();
			}
		}
		
	});

	var initialize = function(){
		new AppRouter();
		Backbone.history.start();
	};

	return {
		initialize: initialize
	};
});
